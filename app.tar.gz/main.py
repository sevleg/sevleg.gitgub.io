import flet as ft
from time import sleep, localtime
from datetime import datetime
from random import randint, choice

dark_theme_flag = False  # флаг задания темы оформления (True -> темная, False -> Светлая)
rotate_value = 0.0  # значение угла поворота игровой надписи
rotate_increment = 0.25  # приращение угла поворота игровой надписи
time_min = localtime().tm_min
time_min = str(time_min) if time_min >= 10 else ("0" + str(time_min))
time_sec = localtime().tm_sec
time_sec = str(time_sec) if time_sec >= 10 else ("0" + str(time_sec))

start_time_date = datetime.now()  # время старта игры как объект time
start_time_str = (
		str(localtime().tm_hour) + ":" + time_min)  # время старта игры как строка формата ЧЧ:ММ

game_world_list = [
	"АБ", "АВ", "АГ", "АД", "АЖ", "ЛЕ", "ЛИ", "ЛО", "ЛУ", "ЛЫ", "АЗ", "АЙ", "АК", "АЛ", "АМ",
	"ЛЮ", "ЛЯ", "МА", "МЕ", "МИ", "АН", "АП", "АР", "АС", "АТ", "МО", "МУ", "МЯ", "НА", "НЕ",
	"АЦ", "АЧ", "АШ", "БА", "БЕ", "НИ", "НО", "НУ", "НЫ", "НЯ", "БО", "БУ", "БЫ", "ВА", "ВЕ",
	"ОБ", "ОВ", "ОГ", "ОД", "ОЗ", "ВИ", "ВО", "ВУ", "ВЫ", "ВЯ", "ОЙ", "ОК", "ОЛ", "ОМ", "ОН",
	"ГА", "ГИ", "ГО", "ГУ", "ДА", "ОП", "ОР", "ОС", "ОТ", "ОХ", "ДЕ", "ДИ", "ДО", "ДЯ", "ЕВ",
	"ОЧ", "ПА", "ПЕ", "ПИ", "ПО", "ЕД", "ЕЖ", "ЕЗ", "ЕК", "ЕЛ", "ПУ", "РА", "РЕ", "РИ", "РО",
	"ЕМ", "ЕН", "ЕП", "ЕР", "ЕС", "РУ", "РЫ", "СА", "СЕ", "СИ", "ЕТ", "ЖА", "ЖЕ", "ЖИ", "ЖО",
	"СК", "СЛ", "СВ", "СТ", "СУ", "ЗА", "ЗЕ", "ЗИ", "ЗО", "ИВ", "СЫ", "СЯ", "ТА", "ТЕ", "ТИ",
	"ИГ", "ИЗ", "ИК", "ИЛ", "ИМ", "ТО", "ТУ", "ТЫ", "ТЯ", "УБ", "ИН", "ИР", "ИС", "ИТ", "ИЧ",
	"УВ", "УГ", "УД", "УЖ", "УЗ", "КА", "КИ", "КО", "КУ", "ЛА", "УК", "УЛ", "УМ", "УН", "УП",
	"УР", "УС", "УТ", "УХ", "УЧ", "УШ", "ФА", "ФЕ", "ФИ", "ФО", "ХА", "ХО", "ПР", "ЦА", "ЦЕ",
	"ЧА", "ЧЕ", "ЧИ", "ЧУ", "ША", "ШЕ", "ШИ", "ЩА", "ЩЕ", "ЩИ", "ЩУ", "ЮД", "ЮЛ", "ЮР", "ЮТ",
	"ЯВ", "ЯЗ", "ЯЛ", "ЯН", "ЯР", "ЯС", "ЯД", "ЫБ", "БИ", "РЫ", "СП", "КН", "МН", "СТ", "ПЛ",
	"ЗЛ", "КЛ", "СЦ", "ВЛ"]

help_text = (
		"   Правила очень простые: берём небольшой\n" +
		"предмет, например маленький мячик, который\n" +
		"условно будет \"бомбой\". Её передаём по\n" +
		"кругу (от игрока к игроку), причём, чтобы\n" +
		"передать бомбу, нужно назвать любое слово\n" +
		"(существительное, но не имя собственное),\n" +
		"где встречается заданный на экране слог.\n" +
		"Например, на слог \"ГА\" игроки по очереди\n" +
		"называют: ГАЛЕРА, НОГА, ПУГАЛО и т.д.,\n" +
		"главное не повторять уже названные слова!\n" +
		"   Игрок, в чьих руках бомба \"взорвалась\",\n" +
		"проигрывает раунд. Либо можно закончить\n" +
		"раунд принудительно, нажав среднюю кнопку\n" +
		"(кнопку с бомбой). Новый раунд можно начать\n" +
		"кликнув по игровому слогу в центре экрана.\n" +
		"   Нажмите на слово \"БОМБА\" и играйте!\n" +
		"   Веселой и многословной игры Вам! " + u'\u263a')

game_world_list_len = len(game_world_list)
game_world_scale = 1.0
game_stop_flag = False
slow_rotation_flag = False
dark_theme_flag = True  # флаг задания темы оформления (True -> темная, False -> Светлая)

def main(page: ft.Page):
	# ==== Ресурсы ====

	# звуковой эффект старта раунда
	audio_start = ft.Audio(
		src=f"/sounds/start_sound_effect.mp3",
		autoplay=False,
	)
	page.overlay.append(audio_start)

	# звук тикания часов (в течение раунда)
	audio_tik = ft.Audio(
		src=f"/sounds/tik.mp3",
		autoplay=False,
	)
	page.overlay.append(audio_tik)

	# звук взрыва бомбы (окончание раунда)
	audio_explosion = ft.Audio(
		src=f"/sounds/explosion.wav",
		autoplay=False,
	)
	page.overlay.append(audio_explosion)

	# звук теста громкости
	audio_test = ft.Audio(
		src=f"/sounds/test-volume.mp3",
		autoplay=False,
	)
	page.overlay.append(audio_test)
	page.update()

	# иконка бомбочки
	img = ft.Image(
		src=f"/icons/loading-animation.png",
		width=30,
		height=30,
		fit=ft.ImageFit.FIT_HEIGHT,
	)

	page.fonts = {
		"Geologica": "/fonts/Geologica.ttf",
		"linux-libertine-underlined": "/fonts/linux-libertine-underlined.ttf",
		"octicons": "/fonts/octicons.ttf"
	}

	# ==== Функции контролов ====

	# # сворачивание подсказки
	# def w_help_close(e):
	# 	bs_click_help.open = False
	# 	bs_click_help.update()

	# разворачивание подсказки
	def w_help_show(e):
		delta_time_date = datetime.now() - start_time_date
		hours, seconds = divmod(int(delta_time_date.total_seconds()), 3600)
		minutes = seconds // 60

		bs_click_help.content = ft.Container(
			ft.Column(
				[ft.Text("НАЧАЛО ИГРЫ - " + start_time_str +
						 f"\nДЛИТЕЛЬНОСТЬ ИГРЫ - {hours:02}:{minutes:02}"),
				 ft.Text(help_text, font_family="octicons", size=13)
				 # ft.ElevatedButton("Закрыть подсказку", on_click=w_help_close)
				 ],
				tight=True,
				horizontal_alignment="center"
			),
			padding=5
		)
		bs_click_help.open = True
		bs_click_help.update()

	# смена темы
	def w_change_theme(e):
		global dark_theme_flag
		page.theme_mode = "dark" if dark_theme_flag else "light"
		dark_theme_flag = False if dark_theme_flag else True
		page.update()

	# выбор вращения
	def radio_item_changed(e):
		global rotate_increment, rotate_value
		if radio_group_rotate.value == "+":
			rotate_increment = 0.25
		elif radio_group_rotate.value == "-":
			rotate_increment = -0.25
		elif radio_group_rotate.value == "0":
			rotate_value = 0.0
			rotate_increment = 0.0
			game_world.rotate = 0
		else:
			rotate_value = 1.57
			rotate_increment = 0.0
			game_world.rotate = 1.57
		page.update()

	def slow_rotation_clicked(e):
		global slow_rotation_flag
		e.control.checked = not e.control.checked
		slow_rotation_flag = not slow_rotation_flag
		page.update()

	# изменение ползунка громкости
	def slider_changed(e):
		if e.control.value == 0:
			icon_btn_sound.icon = ft.icons.VOLUME_OFF_OUTLINED
			audio_start.volume = 0
			audio_tik.volume = 0
			audio_explosion.volume = 0

		elif e.control.value > 0:
			icon_btn_sound.icon = ft.icons.VOLUME_UP_OUTLINED
			audio_start.volume = audio_tik.volume = audio_explosion.volume = e.control.value * 0.01
			audio_test.volume = e.control.value * 0.01
			audio_test.play()
		page.update()

	# увеличение размера шрифта игрового слога
	def w_game_world_scale_up(e):
		global game_world_scale
		if game_world_scale <= 3:
			btn_game_world_down.disabled = False
			game_world_scale += 0.2
			game_world.scale = game_world_scale
			page.update()
		else:
			btn_game_world_up.disabled = True

	# уменьшение размера шрифта игрового слога
	def w_game_world_scale_down(e):
		global game_world_scale
		if game_world_scale >= 1:
			btn_game_world_up.disabled = False
			game_world_scale -= 0.2
			game_world.scale = game_world_scale
			page.update()
		else:
			btn_game_world_down.disabled = True

	# останов раунда
	def w_stop_game(e):
		global game_stop_flag
		game_stop_flag = True

	# запуск раунда
	def w_start_game(e):
		global rotate_value, rotate_increment, game_world_list, game_world_list_len, \
			game_world_scale, game_stop_flag

		if len(game_world_list) == game_world_list_len:
			game_world.font_family = "linux-libertine-underlined"
			game_world.weight = ft.FontWeight.W_300
			game_world.scale = game_world_scale
			game_world.size = 150
			game_world.color = "green"
			game_world.value = ""

		page.floating_action_button.disabled = False
		dropdown_rotate.disabled = True
		btn_help.disabled = True
		theme_btn.disabled = True
		dropdown_rotate.disabled = True
		sound_slider.disabled = True
		icon_btn_sound.disabled = True
		btn_game_world_down.disabled = True
		btn_game_world_up.disabled = True

		page.update()
		game_world_in_action = choice(game_world_list)
		game_world_list.remove(game_world_in_action)
		game_world.spans = [ft.TextSpan(game_world_in_action)]
		page.update()

		game_world.rotate = rotate_value
		game_world.color = "blue"
		audio_start.play()
		page.update()
		game_world.color = "red"
		page.update()
		sleep(0.25)
		game_world.color = "blue"
		page.update()
		sleep(0.25)
		game_world.color = "red"
		page.update()
		sleep(0.25)
		game_world.color = "green"
		page.update()
		sleep(0.25)

		audio_tik.play()
		sec_value = randint(20, 200)  # диапазон продолжительности раунда в секундах

		while sec_value > 0:
			sleep(0.75) if slow_rotation_flag else sleep(0.25)
			rotate_value += rotate_increment
			game_world.rotate = rotate_value
			if game_stop_flag:
				game_stop_flag = False
				break
			page.update()
			sleep(0.25)
			sec_value -= 1
		game_world.color = "red"
		audio_tik.pause()
		page.update()
		sleep(0.1)
		audio_explosion.play()

		game_world.spans = [
			ft.TextSpan(
				game_world_in_action,
				ft.TextStyle(
					decoration=ft.TextDecoration.LINE_THROUGH,
					decoration_thickness=2
				),
				on_click=w_start_game
			)
		]
		page.update()

		btn_help.disabled = False
		theme_btn.disabled = False
		dropdown_rotate.disabled = False
		page.floating_action_button.disabled = True
		sound_slider.disabled = False
		icon_btn_sound.disabled = False
		btn_game_world_down.disabled = False
		btn_game_world_up.disabled = False
		page.update()

		if len(game_world_list) == 0:  # если был последний раунд
			sleep(1)
			game_world.font_family = "Geologica"
			game_world.size = 50
			game_world.rotate = 0
			game_world.color = "red"
			game_world.value = "ИГРА\nОКОНЧЕНА"
			page.floating_action_button.visible = False
			dropdown_rotate.disabled = True
			page.update()
			return 0

		page.floating_action_button.visible = True
		page.update()

	# ==== Начальные настройки ====

	page.horizontal_alignment = page.vertical_alignment = "center"

	# ==== Виджеты (описания для добавления на страницу) ====

	# кнопка для чтения правил
	btn_help = ft.IconButton(ft.icons.DEVICE_UNKNOWN_SHARP, on_click=w_help_show)

	# Нижняя выдвижная подсказка
	bs_click_help = ft.BottomSheet(
		ft.Container(
			ft.Column(
				[ft.Text("ПРОЧИТАЙТЕ ПОДСКАЗКУ "),
				 ft.Text(help_text,
						 font_family="octicons",
						 size=13
						 )
				 # ft.ElevatedButton("Закрыть подсказку", on_click=w_help_close)
				 ],
				tight=True,
				horizontal_alignment="center"
			),
			padding=5
		),
		open=True
	)

	# кнопка изменения темы (темная / светлая)
	theme_btn = ft.IconButton(ft.icons.BRIGHTNESS_4_OUTLINED, on_click=w_change_theme)

	radio_group_rotate = ft.RadioGroup(content=ft.Column([
		ft.Radio(value="+", label="вращение  " + u'\u2b6e'),
		ft.Radio(value="-", label="вращение  " + u'\u2b6f'),
		ft.Radio(value="0", label="без вращ.   " + u'\u15c5'),
		ft.Radio(value="90", label="без вращ.   " + u'\u15c6')
	],
	), on_change=radio_item_changed)
	radio_group_rotate.value = "+"

	# rotate_confirm_btn = ft.PopupMenuItem(icon=ft.icons.EXPLORE_SHARP, text="ПОДТВЕРДИТЬ")

	dropdown_rotate = ft.PopupMenuButton(
		icon=ft.icons.EXPLORE_SHARP,
		items=[
			radio_group_rotate,
			ft.PopupMenuItem(text=" Медленное вращение", checked=False,
							 on_click=slow_rotation_clicked)
			# rotate_confirm_btn
		]
	)

	game_world = ft.Text(
		"",
		text_align=ft.TextAlign.CENTER,
		disabled=False,
		spans=[
			ft.TextSpan(
				"БОМБА",
				ft.TextStyle(
					# decoration=ft.TextDecoration.UNDERLINE,
					# decoration_thickness=3
					color="green"
				),

				on_click=w_start_game
			)
		]
	)

	game_world.font_family = "Geologica"
	game_world.size = 60

	icon_btn_sound = ft.IconButton(icon=ft.icons.VOLUME_UP_OUTLINED, icon_color=ft.colors.WHITE)

	sound_slider = ft.Slider(min=0, max=100, divisions=10, value=100, label="{value}%", width=90,
							 on_change=slider_changed)

	# кнопка-иконка уменьшения размера шрифта
	btn_game_world_down = ft.IconButton(icon=ft.icons.TEXT_DECREASE_ROUNDED,
										icon_color=ft.colors.WHITE,
										on_click=w_game_world_scale_down)
	# кнопка-иконка увеличения размера шрифта
	btn_game_world_up = ft.IconButton(icon=ft.icons.TEXT_INCREASE_SHARP,
									  icon_color=ft.colors.WHITE, on_click=w_game_world_scale_up)

	# ==== Виджеты (прямое добавление на страницу) ====

	# Верхняя панель
	page.appbar = ft.AppBar(
		title=ft.Text(" Игра «БОМБА»"),
		automatically_imply_leading=False,
		center_title=False,
		bgcolor=ft.colors.SURFACE_VARIANT,
		actions=[
			btn_help,  # кнопка правил
			theme_btn,  # кнопка переключения темы
			dropdown_rotate  # выбор вращения
		]
	)

	# Центральная кнопка старта раунда
	page.floating_action_button = ft.FloatingActionButton(
		content=ft.Row([img], alignment="center"),
		bgcolor=ft.colors.AMBER_200,
		shape=ft.RoundedRectangleBorder(radius=20),
		width=40,
		height=40,
		mini=True,
		on_click=w_stop_game)
	page.floating_action_button_location = ft.FloatingActionButtonLocation.CENTER_DOCKED
	page.floating_action_button.disabled = True

	# Нижняя панель
	page.bottom_appbar = ft.BottomAppBar(
		bgcolor=ft.colors.BLUE,
		shape=ft.NotchShape.CIRCULAR,
		height=70.0,
		content=ft.Row(
			controls=[
				icon_btn_sound,  # кнопка-иконка откл. звука
				sound_slider,  # ползунок громкости
				ft.Container(expand=True),  # разделитель серединный
				btn_game_world_down,  # кнопка-иконка уменьшения размера шрифта
				btn_game_world_up,  # кнопка-иконка увеличения размера шрифта
			]
		),
	)

	# ==== Добавление виджетов на страницу ====

	page.add(game_world, bs_click_help)


ft.app(target=main, assets_dir="assets")
